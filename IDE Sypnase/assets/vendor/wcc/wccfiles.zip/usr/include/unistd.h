#pragma once

#include <stddef.h>           
#include <stdint.h>                       
#include <sys/types.h>                          

#define STDIN_FILENO   (0)
#define STDOUT_FILENO  (1)
#define STDERR_FILENO  (2)

struct clone_args {
  uint64_t flags;                            
  uint64_t pidfd;                                             
                                      
  uint64_t child_tid;                                
                                                          
  uint64_t parent_tid;                               
                                                           
  uint64_t exit_signal;                                   
                                                
  uint64_t stack;                                             
  uint64_t stack_size;                      
  uint64_t tls;                                   
  uint64_t set_tid;                                 
                                                
  uint64_t set_tid_size;                                 
                                                
  uint64_t cgroup;                                           
                                                         
};

ssize_t write(int fd, const void *str, size_t len);
int close(int fd);
ssize_t read(int fd, void *buf, size_t size);
off_t lseek(int fd, off_t offset, int whence);
int unlink(const char *pathname);
int rmdir(const char *pathname);
char *getcwd(char *buffer, size_t size);
int chdir(const char *path);

int brk(void *addr);
void *sbrk(intptr_t increment);

#if !defined(__wasm)
int unlinkat(int dirfd, const char *pathname, int flags);
int dup(int);
int pipe(int*);
int pipe2(int *pipefd, int flag);
int isatty(int fd);

pid_t fork(void);
long clone3(struct clone_args *cl_args, size_t size);
int execvp(const char *, char *const[]);
int execve(const char *, char *const[], char *const[]);

pid_t getpid(void);
pid_t getppid(void);
#endif
