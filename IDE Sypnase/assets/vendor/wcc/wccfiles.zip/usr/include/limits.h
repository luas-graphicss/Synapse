#pragma once

#define CHAR_BIT   (8)                               

#define CHAR_MIN   (-128)           
#define CHAR_MAX   (127)              
#define UCHAR_MAX  (255)             

#define SHRT_MIN   (-32768)            
#define SHRT_MAX   ( 32767)              
#define USHRT_MAX  (65535)             

#define INT_MIN    (-2147483648)            
#define INT_MAX    ( 2147483647)              
#define UINT_MAX   (4294967295)             

#if defined(__ILP32__)

#define LONG_MIN   (-2147483648)            
#define LONG_MAX   ( 2147483647)              
#define ULONG_MAX  (4294967295)             

#define LLONG_MIN  (-9223372036854775808LL)            
#define LLONG_MAX  ( 9223372036854775807LL)              
#define ULLONG_MAX (18446744073709551615ULL)             

#elif defined(__LP64__)

#define LONG_MIN   (-9223372036854775808L)            
#define LONG_MAX   ( 9223372036854775807L)              
#define ULONG_MAX  (18446744073709551615UL)             

#define LLONG_MIN  (-9223372036854775808LL)            
#define LLONG_MAX  ( 9223372036854775807LL)              
#define ULLONG_MAX (18446744073709551615ULL)             

#endif

#define PATH_MAX  (512)
