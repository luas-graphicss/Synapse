#pragma once

#include <stdint.h>              

#if defined(__wasm)
typedef uintptr_t jmp_buf[2];                                       

#elif defined(__aarch64__)
typedef uintptr_t jmp_buf[192 / 8];

#elif defined(__x86_64__)
typedef uintptr_t jmp_buf[200 / 8];        

#elif defined(__riscv)
typedef uintptr_t jmp_buf[208 / 8];
#endif

int setjmp(jmp_buf env);
_Noreturn void longjmp(jmp_buf env, int result);

#define _setjmp   setjmp
#define _longjmp  longjmp

#ifdef __wasm
#define setjmp(env)           __builtin_setjmp(env)
#define longjmp(env, result)  __builtin_longjmp(env, result)
#endif
