#pragma once

#include <time.h>             
#include <stddef.h>           
#include <stdint.h>
#include <sys/types.h>          

typedef unsigned long ino_t;
typedef uint32_t uid_t;
typedef uint32_t gid_t;
typedef unsigned long blkcnt_t;

#if defined(__APPLE__)
typedef int32_t dev_t;
typedef uint16_t mode_t;
typedef uint16_t nlink_t;
typedef int32_t blksize_t;

                         
struct stat {
  dev_t       st_dev;                                                         
  mode_t      st_mode;                                                    
  nlink_t     st_nlink;                                               
  uint64_t    st_ino;                                               
  uid_t       st_uid;                                                
  gid_t       st_gid;                                                 
  dev_t       st_rdev;                                     

                                 
  struct timespec st_atimespec;                                    
  struct timespec st_mtimespec;                                               
  struct timespec st_ctimespec;                                           
  struct timespec st_birthtimespec;                                         

  off_t       st_size;                                               
  blkcnt_t    st_blocks;                                                   
  blksize_t   st_blksize;                                                  
  uint32_t    st_flags;                                                
  uint32_t    st_gen;                                             
  int32_t     st_lspare;                                         
  int64_t     st_qspare[2];                                      
};
#elif defined(__x86_64__)
typedef unsigned long dev_t;
typedef int mode_t;
typedef unsigned long nlink_t;
typedef unsigned long blksize_t;

struct stat {
  dev_t     st_dev;
  ino_t     st_ino;
  nlink_t   st_nlink;
  mode_t    st_mode;
  uid_t     st_uid;
  gid_t     st_gid;
  int __pad0;
  dev_t     st_rdev;
  off_t     st_size;
  blksize_t st_blksize;
  blkcnt_t  st_blocks;

  struct timespec st_atim;
  struct timespec st_mtim;
  struct timespec st_ctim;

#define st_atime st_atim.tv_sec
#define st_mtime st_mtim.tv_sec
#define st_ctime st_ctim.tv_sec

                        long __glibc_reserved[3];
};

#else
typedef unsigned long dev_t;
typedef int mode_t;
typedef unsigned int nlink_t;
typedef unsigned long blksize_t;

struct stat {
  dev_t     st_dev;
  ino_t     st_ino;
  mode_t    st_mode;
  nlink_t   st_nlink;
  uid_t     st_uid;
  gid_t     st_gid;
  dev_t     st_rdev;
  dev_t __pad1;
  off_t     st_size;
  blksize_t st_blksize;
  blkcnt_t  st_blocks;

  struct timespec st_atim;
  struct timespec st_mtim;
  struct timespec st_ctim;

#define st_atime st_atim.tv_sec
#define st_mtime st_mtim.tv_sec
#define st_ctime st_ctim.tv_sec

  int __glibc_reserved[2];
};
#endif

int mkdir(const char *pathname, mode_t mode);
int mkdirat(int dirfd, const char *pathname, mode_t mode);

int chmod(const char *pathname, mode_t mode);
int fchmodat(int dirfd, const char *pathname, mode_t mode, int flags);

#define S_IFMT    0170000
#define S_IFIFO   0010000
#define S_IFCHR   0020000
#define S_IFDIR   0040000
#define S_IFBLK   0060000
#define S_IFREG   0100000
#define S_IFLNK   0120000
#define S_IFSOCK  0140000

#define S_ISREG(m)   (((m) & S_IFMT) == S_IFREG)
#define S_ISDIR(m)   (((m) & S_IFMT) == S_IFDIR)
#define S_ISCHR(m)   (((m) & S_IFMT) == S_IFCHR)
#define S_ISBLK(m)   (((m) & S_IFMT) == S_IFBLK)
#define S_ISLNK(m)   (((m) & S_IFMT) == S_IFLNK)
#define S_ISSOCK(m)  (((m) & S_IFMT) == S_IFSOCK)
#define S_ISFIFO(m)  (((m) & S_IFMT) == S_IFFIFO)

int stat(const char *pathname, struct stat *buf);
int fstat(int fd, struct stat *buf);
int lstat(const char *pathname, struct stat *buf);
int fstatat(int fd, const char *pathname, struct stat *buf, int flag);

#if defined(__APPLE__)
                         
int stat64(const char *pathname, struct stat *buf);
int fstat64(int fd, struct stat *buf);
int lstat64(const char *pathname, struct stat *buf);
int fstatat64(int fd, const char *pathname, struct stat *buf, int flag);
#define stat(pathname, buf)   stat64(pathname, buf)
#define fstat(pathname, buf)  fstat64(pathname, buf)
#define lstat(pathname, buf)  lstat64(pathname, buf)
#define fstatat(fd, p, b, f)  fstatat64(fd, p, b, f)
#endif
